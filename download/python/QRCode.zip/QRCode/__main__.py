# KaliBasenji42's Website
# Copyright (C) 2025 KaliBasenji42

# This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; version 2 of the License.

# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

# You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

# License: https://kalibasenji.xeroideas.org/LICENSE.md
# GPL v2: https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html
# KaliBasenji42's Github: https://github.com/KaliBasenji42

import qrcode

# Variables

run = True

path = ''
cont = ''

# Functions

# Main Loop

print('This is program is licensed under the GPL v2 license\n')
print('Input "cont" to set QR Code content')
print('Input "path" to set file path')
print('Input "out" to save to file path')
print('Input "quit" to quit')
print('')

while run:
  
  inp = input('Input: ')
  print('')
  
  if inp.lower() == 'quit': run = False
  
  elif inp.lower() == 'cont':
    
    cont = input('Content: ')
    print('')
    
    print('Cont set to "' + cont + '"\n')
    
  
  elif inp.lower() == 'path':
    
    path = input('File path (no extension): ') + '.png'
    print('')
    
    print('Path set to "' + path + '"\n')
    
  
  elif inp.lower() == 'out':
    
    img = qrcode.make(cont)
    
    type(img)
    
    img.save(path)
    
    print('Image Saved!\n')
    
  
