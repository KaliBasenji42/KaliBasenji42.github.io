# KaliBasenji42's Website
# Copyright (C) 2025 KaliBasenji42

# This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; version 2 of the License.

# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

# You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

# License: https://kalibasenji.xeroideas.org/LICENSE.md
# GPL v2: https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html
# KaliBasenji42's Github: https://github.com/KaliBasenji42
print('This is program is licensed under the GPL v2 license')

## Setup ###

import pygame
import random
import math

pygame.init()

### Variables ###

screenWidth = 1200
screenHeight = 600

FPS = 60
time = 0
run = True

play = True
selectMode = False

mass = 20
planetValues = []
gravConst = 1
zoom = 0

upKey = False
downKey = False
upKeyTime = 0
downKeyTime = 0

mouseStart = (0, 0)
mouseDown = False

### Game Setup ###

screen = pygame.display.set_mode((screenWidth, screenHeight))
pygame.display.set_caption('Gravity')
font = pygame.font.Font(None, 50)

clock = pygame.time.Clock()

### Images ###

pauseImg = pygame.image.load('Images/Pause.png').convert()
playImg = pygame.image.load('Images/Play.png').convert()

resetImg = pygame.image.load('Images/Restart.png').convert()

addImg = pygame.image.load('Images/Add.png').convert()
minusImg = pygame.image.load('Images/Minus.png').convert()

massImg = pygame.image.load('Images/Mass.png').convert()

planetImg = pygame.image.load('Images/Planet.png').convert()
toolImg = pygame.image.load('Images/Tool.png').convert()

deleteImg = pygame.image.load('Images/X.png').convert()

lockImg = pygame.image.load('Images/Locked.png').convert()

zoomImg = pygame.image.load('Images/Zoom.png').convert()

numImg0 = pygame.image.load('Images/0.png').convert()
numImg1 = pygame.image.load('Images/1.png').convert()
numImg2 = pygame.image.load('Images/2.png').convert()
numImg3 = pygame.image.load('Images/3.png').convert()
numImg4 = pygame.image.load('Images/4.png').convert()
numImg5 = pygame.image.load('Images/5.png').convert()
numImg6 = pygame.image.load('Images/6.png').convert()
numImg7 = pygame.image.load('Images/7.png').convert()
numImg8 = pygame.image.load('Images/8.png').convert()
numImg9 = pygame.image.load('Images/9.png').convert()

numberImg = [numImg0, numImg1, numImg2, numImg3, numImg4,
             numImg5, numImg6, numImg7, numImg8, numImg9]

### Functions ###

def randomVel(min, max):
    
    return random.randint(min, max) * (random.randint(0, 1) - 0.5) * 2
    

def hue(v):
    
    r = abs(v-3)-1
    g = -abs(v-2)+2
    b = -abs(v-4)+2
    
    if(r < 0):
        r = 0
    if(g < 0):
        g = 0
    if(b < 0):
        b = 0
    
    if(r > 1):
        r = 1
    if(g > 1):
        g = 1
    if(b > 1):
        b = 1
    
    return (r * 255, g * 255, b * 255)
    

def reset():
    
    for planet in planets:
        
        planet.delete()
        
    

### Sprites ###

class Planet(pygame.sprite.Sprite):
    
    def __init__(self, color, pos, vel, mass):
        
        self.r = round(math.sqrt(mass)) * 2
        self.color = color
        
        pygame.sprite.Sprite.__init__(self)
        
        self.image = pygame.Surface([self.r * 2, self.r * 2], pygame.SRCALPHA)
        pygame.draw.circle(self.image, self.color, (self.r, self.r), self.r)
        self.rect = self.image.get_rect()
        self.rect.center = pos
        
        self.pos = [pos[0], pos[1]]
        self.vel = [vel[0], vel[1]]
        self.mass = mass
        self.force = [0, 0]
        self.rand = random.random()
        self.locked = False
        self.selected = False
        
    
    def update(self):
        
        # Out of Bounds
        
        if abs(self.pos[0]) > 1000000 or abs(self.pos[1]) > 1000000:
            
            self.kill()
            
        
        # Values
        
        global planetValues, gravConst
        
        self.force = [0, 0]
        
        for values in planetValues:
            
            # Distance
            
            dist = math.sqrt(abs((values[0] - self.pos[0]) ** 2 +
                                 (values[1] - self.pos[1]) ** 2))
            
            # Gravity
            
            if dist > 5:
                
                forceDir = [0, 0]
                forceAmp = 0
                
                forceDir[0] = (values[0] - self.pos[0]) / dist
                forceDir[1] = (values[1] - self.pos[1]) / dist
                
                forceAmp = ((self.mass * values[2]) / (dist ** 2)) * gravConst
                
                self.force[0] += forceDir[0] * forceAmp
                self.force[1] += forceDir[1] * forceAmp
                
            
            # Merge
            
            while self.rand == values[4] and dist > 0:
                
                self.rand = random.random()
                
            
            if (dist < self.r + values[3] and dist > 0 and 
                self.mass + self.rand > values[2] + values[4]):
                
                self.vel[0] = (((self.vel[0] * self.mass) +
                                (values[5] * values[2])) /
                               (self.mass + values[2]))
                self.vel[1] = (((self.vel[1] * self.mass) +
                                (values[6] * values[2])) /
                               (self.mass + values[2]))
                
                self.mass += values[2]
                self.r = round(math.sqrt(self.mass)) * 2
                
            
            if (dist < self.r + values[3] and dist > 0 and 
                self.mass + self.rand < values[2] + values[4]):
                
                self.kill()
                
            
        
        # Acceleration
        
        self.vel[0] += self.force[0] / self.mass
        self.vel[1] += self.force[1] / self.mass
        
        self.vel[0] = round(self.vel[0], 6)
        self.vel[1] = round(self.vel[1], 6)
        
        # Velocity & Pos
        
        if self.locked:
            
            self.vel = [0, 0]
            
        
        self.pos[0] += self.vel[0]
        self.pos[1] += self.vel[1]
        
        self.pos[0] = round(self.pos[0], 6)
        self.pos[1] = round(self.pos[1], 6)
        
    
    def updateGraphics(self, zoom):
        
        size = self.r / (2 ** zoom)
        
        if size < 1: size = 1
        
        self.image = pygame.Surface([size * 2, size * 2], pygame.SRCALPHA)
        pygame.draw.circle(self.image, self.color,(size, size), size)
        
        x = (self.pos[0] / (2 ** zoom)) + (screenWidth / 2)
        y = (self.pos[1] / (2 ** zoom)) + (screenHeight / 2)
        
        self.rect = pygame.Rect(x - size, y - size, size * 2, size * 2)
        
        if self.selected:
            
            pygame.draw.circle(self.image, (129, 129, 192),
                               (size, size), size, width = 2)
            
        
        if self.locked:

            pygame.draw.circle(self.image, (128, 128, 128), (size, size), 2)
            
        
    
    def delete(self):
        
        self.kill()
        
    
    def mouseSelect(self, pos):
        
        if self.rect.collidepoint(pos):
            
            self.selected = True
            
        else:
            
            self.selected = False
            
        
    
    def deleteSelected(self):
        
        if self.selected:
            
            self.kill()
            
        
    
    def lockSelected(self):
        
        if self.selected:
            
            self.locked = not self.locked
            
        
    
    def returnValues(self):
        
        return [self.pos[0], self.pos[1], self.mass, self.r, self.rand,
                self.vel[0], self.vel[1]]
        
    

planets = pygame.sprite.Group()

### Objects ###

background = pygame.Surface((screenWidth, screenHeight))
background.fill((32, 0, 32, 255))

panel = pygame.Surface((screenWidth, 24))
panel.fill((128, 128, 128, 255))

crossHairs = pygame.Surface((5, 5))
crossHairs.fill((128, 128, 128, 255))
crossHairsRect = crossHairs.get_rect(center = (-20, -20))

velVector = pygame.Surface((5, 5))
velVector.fill((128, 128, 128, 255))
velVectorRect = velVector.get_rect(center = (-20, -20))

pauseButton = pygame.Rect(0, 0, 24, 24)

resetButton = resetImg.get_rect(topleft = (24, 0))

addMassButton = addImg.get_rect(topleft = (72, 0))

minusMassButton = minusImg.get_rect(topleft = (96, 0))

massRect = massImg.get_rect(topleft = (156, 0))

selectModeButton = pygame.Rect(204, 0, 24, 24)

deleteButton = deleteImg.get_rect(topleft = (252, 0))

lockButton = lockImg.get_rect(topleft = (276, 0))

minusZoomButton = minusImg.get_rect(topleft = (screenWidth - 60, 0))

addZoomButton = addImg.get_rect(topleft = (screenWidth - 84, 0))

zoomRect = zoomImg.get_rect(topleft = (screenWidth - 24, 0))

### Main Loop ###

while run:
    
    # FPS
    
    clock.tick(FPS)
    
    time += 1
    
    ### Events ###
    
    for event in pygame.event.get():
        
        # Quit

        if event.type == pygame.QUIT: run = False
        
        ### Key Press ###
        
        if event.type == pygame.KEYDOWN:
            
            # Pause / Play
            
            if event.key == pygame.K_SPACE: play = not play
            
            # Reset
            
            if event.key == pygame.K_r: reset()
            
            # Select
            
            if event.key == pygame.K_s: selectMode = not selectMode
            
            # Delete
            
            if event.key == pygame.K_BACKSPACE:
                
                for planet in planets:
                    
                    planet.deleteSelected()
                    
                
            
            # Lock
            
            if event.key == pygame.K_l:
                
                for planet in planets:
                    
                    planet.lockSelected()
                    
                
            
            # Mass
            
            if event.key == pygame.K_UP: upKey = True
            
            if event.key == pygame.K_DOWN: downKey = True
            
            # Zoom
            
            if event.key == pygame.K_EQUALS and zoom < 9: zoom += 1
            
            if event.key == pygame.K_MINUS and zoom > 0: zoom += -1
            
        
        ### Key Release ###
        
        if event.type == pygame.KEYUP:
            
            # Mass
            
            if event.key == pygame.K_UP: upKey = False
            
            if event.key == pygame.K_DOWN: downKey = False
            
        
        ### Mouse Press ###
        
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            
            # Pause / Play
            
            if pauseButton.collidepoint(event.pos): play = not play
            
            # Reset
            
            if resetButton.collidepoint(event.pos): reset()
            
            # Select
            
            if selectModeButton.collidepoint(event.pos):
                
                selectMode = not selectMode
                
            
            if selectMode and event.pos[1] > 24:
                
                for planet in planets:
                    
                    planet.mouseSelect(event.pos)
                    
                
            
            # Delete
            
            if deleteButton.collidepoint(event.pos):
                
                for planet in planets:
                    
                    planet.deleteSelected()
                    
                
            
            # Lock
            
            if lockButton.collidepoint(event.pos):
                
                for planet in planets:
                    
                    planet.lockSelected()
                    
                
            
            # Mass
            
            if addMassButton.collidepoint(event.pos) and mass < 100: mass += 1
            
            if minusMassButton.collidepoint(event.pos) and mass > 1: mass += -1
            
            # Zoom
            
            if addZoomButton.collidepoint(event.pos) and zoom < 9: zoom += 1
            
            if minusZoomButton.collidepoint(event.pos) and zoom > 0: zoom += -1
            
            # Place Planet
            
            mouseStart = event.pos
            
            if event.pos[1] > 24 and not selectMode:
                
                mouseDown = True
                
                start = ((event.pos[0] - (screenWidth / 2)) * (2 ** zoom),
                              (event.pos[1] - (screenHeight / 2)) * (2 ** zoom))
                
                crossHairsRect.center = event.pos
                
            
        
        ### Mouse Release ###
        
        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            
            # Place Planet
            
            if mouseStart[1] > 24 and not selectMode:
                
                mouseDown = False
                crossHairsRect.center = (-20, -20)
                velVectorRect.center = (-20, -20)
                
                end = ((event.pos[0] - (screenWidth / 2)) * (2 ** zoom),
                       (event.pos[1] - screenHeight / 2) * (2 ** zoom))
                
                vx = (start[0] - end[0]) / 100
                vy = (start[1] - end[1]) / 100
                
                color = hue(random.random() * 6)
                
                planet = Planet(color, start, [vx, vy], mass)
                planets.add(planet)
                
            
        
        ### Mouse Motion ###
        
        if event.type == pygame.MOUSEMOTION:
            
            # Place Planet
            
            if mouseDown:
                
                velVectorRect.centerx = ((mouseStart[0] - event.pos[0])
                                         + mouseStart[0])
                velVectorRect.centery = ((mouseStart[1] - event.pos[1])
                                         + mouseStart[1])
                
            
        
    
    ### Behavior ###
    
    # Planets
    
    planetValues = []
    
    for planet in planets:
        
        planetValues.append(planet.returnValues())
        
        planet.updateGraphics(zoom)
        
    
    if play: planets.update()
    
    # Mass
    
    if upKey: upKeyTime += 1
    
    else: upKeyTime = -1
    
    if downKey: downKeyTime += 1
    
    else: downKeyTime = -1
    
    if (upKey and not downKey and mass < 500 and
        (upKeyTime > 50 or upKeyTime == 0)):
        
        mass += 1
        
    
    if (downKey and not upKey and mass > 1 and
        (downKeyTime > 50 or downKeyTime == 0)):
        
        mass += -1
        
    
    ### Blit ###
    
    screen.blit(background, (0, 0))
    
    planets.draw(screen)
    
    if not selectMode:
        
        screen.blit(crossHairs, crossHairsRect)
        screen.blit(velVector, velVectorRect)
        
    
    screen.blit(panel, (0, 0))
    screen.blit(resetImg, resetButton)
    screen.blit(deleteImg, deleteButton)
    screen.blit(addImg, addMassButton)
    screen.blit(minusImg, minusMassButton)
    screen.blit(massImg, massRect)
    screen.blit(lockImg, lockButton)
    screen.blit(addImg, addZoomButton)
    screen.blit(minusImg, minusZoomButton)
    screen.blit(zoomImg, zoomRect)
    
    # Select Button
    
    if selectMode: screen.blit(toolImg, selectModeButton)
    
    else: screen.blit(planetImg, selectModeButton)
    
    # Pause / Play
    
    if play: screen.blit(pauseImg, pauseButton)
    
    else: screen.blit(playImg, pauseButton)
    
    # Numbers
    
    screen.blit(numberImg[(mass // 100) % 10], (120, 0))
    screen.blit(numberImg[(mass // 10) % 10], (132, 0))
    screen.blit(numberImg[mass % 10], (144, 0))
    
    screen.blit(numberImg[zoom % 10], ((screenWidth - 36), 0))
    
    ### Render ###
    
    pygame.display.update()
    

# Quit

pygame.quit()
