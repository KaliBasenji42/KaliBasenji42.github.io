# KaliBasenji42's Website
# Copyright (C) 2025 KaliBasenji42

# This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; version 2 of the License.

# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

# You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

# License: https://kalibasenji.xeroideas.org/LICENSE.md
# GPL v2: https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html
# KaliBasenji42's Github: https://github.com/KaliBasenji42
print('This is program is licensed under the GPL v2 license')

# Setup

import pygame
import math
import random

from sys import exit

pygame.init()

screen = pygame.display.set_mode((600, 400))
pygame.display.set_caption('Pong')
font = pygame.font.Font(None, 50)

clock = pygame.time.Clock()

# Variables

arial16 = pygame.font.SysFont('Arial', 16)
time = 0
multiplayer = False
play = False
FPS = 60
turbo = False
score = [0, 0]
modes = ['Human', 'Easy', 'Medium', 'Hard', 'Very Hard']

maxBallSpeed = 12
ballStartSpeed = 3
ballAcc = 0.2

paddlePos = [150, 150]
paddleDir = [0, 0]
paddleVel = [0, 0]
paddleBonus = [0, 0]
paddleDown = [False, False]
paddleUp = [False, False]
mode = [0, 0]

ballPos = [300, 200]
ballVel = [-ballStartSpeed , random.randrange(-10, 10) / 10]

# Function

def restart():
    
    global play, score, ballStartSpeed
    global paddlePos, paddleDir, paddleVel, paddleBonus
    global ballPos, ballVel
    
    play = False
    
    score = [0, 0]
    
    paddlePos = [150, 150]
    paddleDir = [0, 0]
    paddleVel = [0, 0]
    paddleBonus = [0, 0]
    
    ballPos = [300, 200]
    ballVel = [-ballStartSpeed, random.randrange(-10, 10) / 10]
    

def calculateBallPos(pos, vel, wall1, wall2, x):
    
    if vel[0] * vel[1] == 0: return pos[1]
    
    a = 2 * abs(wall1 - wall2)
    b = vel[1] / (a * vel[0])
    yInt = max(wall1, wall2)
    m = a * b
    c = (yInt - (pos[1] - (m * pos[0]))) / m
    d = min(wall1, wall2)
    
    return a * abs(((b * (x - c)) % 1) - 0.5) + d
    

def sign(val):
    
    if val == 0: return 1
    
    return val / abs(val)
    

# Pygame Objects

background = pygame.Surface((600, 400))
background.fill((128, 128, 128, 255))

top = pygame.Surface((600, 24))
top.fill((195, 195, 195, 255))

bottom = pygame.Surface((600, 24))
bottom.fill((195, 195, 195, 255))

ballSurf = pygame.image.load('Images/Ball.png').convert()
ballRect = ballSurf.get_rect(center = (300, 200))

paddle1ModeSurf = arial16.render('P1: Human', True, (0, 0, 0))
paddle1ModeRect = paddle1ModeSurf.get_rect(topleft = (10, 376))

paddle2ModeSurf = arial16.render('P2: Human', True, (0, 0, 0))
paddle2ModeRect = paddle2ModeSurf.get_rect(topright = (590, 376))

playSurf = pygame.image.load('Images/Play.png').convert()
pauseSurf = pygame.image.load('Images/Pause.png').convert()
pauseButton = pygame.Rect(0, 0, 24, 24)

restartSurf = pygame.image.load('Images/Restart.png').convert()
restartRect = restartSurf.get_rect(topleft = (24, 0))

paddle1Surf = pygame.image.load('Images/Paddle.png').convert()
paddle1Rect = paddle1Surf.get_rect(topleft = (10, 150))

paddle2Surf = pygame.image.load('Images/Paddle.png').convert()
paddle2Rect = paddle2Surf.get_rect(topleft = (580, 150))

score0 = pygame.image.load('Images/0.png').convert()
score1 = pygame.image.load('Images/1.png').convert()
score2 = pygame.image.load('Images/2.png').convert()
score3 = pygame.image.load('Images/3.png').convert()
score4 = pygame.image.load('Images/4.png').convert()
score5 = pygame.image.load('Images/5.png').convert()
score6 = pygame.image.load('Images/6.png').convert()
score7 = pygame.image.load('Images/7.png').convert()
score8 = pygame.image.load('Images/8.png').convert()
score9 = pygame.image.load('Images/9.png').convert()

numberImg = [score0, score1, score2, score3, score4,
             score5, score6, score7, score8, score9]

scoreDivide = pygame.Surface((2, 20))
scoreDivide.fill((0, 0, 195, 255))

# Main Loop

while True:
    
    # Event Loop
    
    for event in pygame.event.get():
        
        # Quit
        
        if event.type == pygame.QUIT:
            
            pygame.quit()
            exit()
            
        
        # Mouse Press
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            
            # Mode
            
            if paddle1ModeRect.collidepoint(event.pos):
                    
                mode[0] += 1
                mode[0] = mode[0] % len(modes)
                
                paddle1ModeSurf = arial16.render('P1: ' + modes[mode[0]],
                                                 True, (0, 0, 0))
                paddle1ModeRect = paddle1ModeSurf.get_rect(topleft = (10, 376))
                
            
            if paddle2ModeRect.collidepoint(event.pos):
                
                mode[1] += 1
                mode[1] = mode[1] % len(modes)
                
                paddle2ModeSurf = arial16.render('P2: ' + modes[mode[1]],
                                                 True, (0, 0, 0))
                paddle2ModeRect = paddle2ModeSurf.get_rect(topright = (590, 376))
                
            
            # Pause / Play
            
            if pauseButton.collidepoint(event.pos):
                
                play = not(play)
                
            
            # Restart
            
            if restartRect.collidepoint(event.pos):
                
                restart()
                
            
        
        # Key Press
        
        if event.type == pygame.KEYDOWN:
            
            # Mode
            
            if event.key == pygame.K_1:
                
                mode[0] += 1
                mode[0] = mode[0] % len(modes)
                
                paddle1ModeSurf = arial16.render('P1: ' + modes[mode[0]],
                                                 True, (0, 0, 0))
                paddle1ModeRect = paddle1ModeSurf.get_rect(topleft = (10, 376))
                
                paddleDown[0] = False
                paddleUp[0] = False
                
            
            if event.key == pygame.K_2:
                
                mode[1] += 1
                mode[1] = mode[1] % len(modes)
                
                paddle2ModeSurf = arial16.render('P2: ' + modes[mode[1]],
                                                 True, (0, 0, 0))
                paddle2ModeRect = paddle2ModeSurf.get_rect(topright = (590, 376))
                
                paddleDown[1] = False
                paddleUp[1] = False
                
            
            # Pause
            
            if event.key == pygame.K_SPACE:
                
                play = not(play)
                
            
            # Restart
            
            if event.key == pygame.K_r:
                
                restart()
                
            
            # Paddle 1       
            
            if event.key == pygame.K_s and play and mode[0] == 0:
                
                paddleDown[0] = True
                
            
            if event.key == pygame.K_w and play and mode[0] == 0:
                
                paddleUp[0] = True
                
            
            # Paddle 2        
            
            if event.key == pygame.K_DOWN and play and mode[1] == 0:
                
                paddleDown[1] = True
                
            
            if event.key == pygame.K_UP and play and mode[1] == 0:
                
                paddleUp[1] = True
                
            
            # FPS
            
            if event.key == pygame.K_t:
                
                turbo = not(turbo)
                
            
        
        # Key Release
        
        if event.type == pygame.KEYUP:
            
            # paddle 1
            
            if event.key == pygame.K_s and play and mode[0] == 0:
                
                paddleDown[0] = False
                
            
            if event.key == pygame.K_w and play and mode[0] == 0:
                
                paddleUp[0] = False
                
            
            # paddle 2
            
            if event.key == pygame.K_DOWN and play and mode[1] == 0:
                
                paddleDown[1] = False
                
            
            if event.key == pygame.K_UP and play and mode[1] == 0:
                
                paddleUp[1] = False
                
            
        
    
    # Computer Operated Paddle
    
    if mode[0] != 0:
        
        target = 0
        
        if mode[0] == 1: target = ballPos[1]
        elif mode[0] == 2:
            
            target = calculateBallPos(ballPos, ballVel, 34, 366, 20)
            target = (target + ballPos[1]) / 2
            
        elif mode[0] == 3: target = calculateBallPos(ballPos, ballVel,
                                                     34, 366, 20)
        elif mode[0] == 4:
            
            base = calculateBallPos(ballPos, ballVel, 34, 366, 20)
            prev = calculateBallPos(ballPos, ballVel, 34, 366, 30)
            
            velDir = sign(base - prev)
            
            if time % (60 * 60) < (60 * 30): velDir = -velDir
            
            target = base - (30 * velDir)
            
        
        paddleDown[0] = False
        paddleUp[0] = False
        
        if paddle1Rect.centery < target - 5:
            
            paddleDown[0] = True
            paddleUp[0] = False
            
        elif paddle1Rect.centery > target + 5:
            
            paddleDown[0] = False
            paddleUp[0] = True
            
        
    
    if mode[1] != 0:
        
        target = 0
        
        if mode[1] == 1: target = ballPos[1]
        elif mode[1] == 2:
            
            target = calculateBallPos(ballPos, ballVel, 34, 366, 580)
            target = (target + ballPos[1]) / 2
            
        elif mode[1] == 3: target = calculateBallPos(ballPos, ballVel,
                                                     34, 366, 580)
        elif mode[1] == 4:
            
            base = calculateBallPos(ballPos, ballVel, 34, 366, 580)
            prev = calculateBallPos(ballPos, ballVel, 34, 366, 570)
            
            velDir = sign(base - prev)
            
            if time % (60 * 60) < (60 * 30): velDir = -velDir
            
            target = base - (30 * velDir)
            
        
        paddleDown[1] = False
        paddleUp[1] = False
        
        if paddle2Rect.centery < target - 5:
            
            paddleDown[1] = True
            paddleUp[1] = False
            
        elif paddle2Rect.centery > target + 5:
            
            paddleDown[1] = False
            paddleUp[1] = True
            
        
    
    # If Play
    
    if play:
    
        # Paddle Math
        
        for i in range(2):
            
            if paddlePos[i] >= 275:
                
                paddlePos[i] = 275
                paddleBonus[i] = 0
                
            
            if paddlePos[i] <= 25:
                
                paddlePos[i] = 25
                paddleBonus[i] = 0
                
            
            if paddleDown[i] and not(paddleUp[i]):
                
                paddleDir[i] = 1
                
            elif paddleUp[i] and not(paddleDown[i]):
                
                paddleDir[i] = -1
                
            else:
                
                paddleDir[i] = 0
                
            
            paddleBonus[i] = paddleBonus[i] * 0.95
            paddleBonus[i] += paddleDir[i] * 0.25
            paddleVel[i] = paddleDir[i] + paddleBonus[i]
            paddlePos[i] += paddleVel[i]
            
        paddle1Rect.top = paddlePos[0]
        paddle2Rect.top = paddlePos[1]
        
        # Ball Math
        
        if ballPos[1] < 35:
            
            ballVel[1] = abs(ballVel[1])
            ballPos[1] = 35
            
        if ballPos[1] > 365:
            
            ballVel[1] = -abs(ballVel[1])
            ballPos[1] = 365
            
            
        
        if ballRect.colliderect(paddle1Rect):
            
            ballVel[0] = abs(ballVel[0])
            if ballVel[0] < maxBallSpeed: ballVel[0] += ballAcc
            ballVel[1] += (ballPos[1] - paddle1Rect.centery)/25
            ballPos[0] = 30
            
        if ballRect.colliderect(paddle2Rect):
            
            ballVel[0] = -abs(ballVel[0])
            if ballVel[0] > -maxBallSpeed: ballVel[0] += -ballAcc
            ballVel[1] += (ballPos[1] - paddle2Rect.centery)/25
            ballPos[0] = 570
            
        
        if ballRect.centerx < -10:
            
            ballPos = [300, 200]
            ballVel = [ballStartSpeed, random.randrange(-10, 10) / 10]
            score[1] += 1
            
        if ballRect.centerx > 610:
            
            ballPos = [300, 200]
            ballVel = [-ballStartSpeed, random.randrange(-10, 10) / 10]
            score[0] += 1
            
        
        ballPos[0] += ballVel[0]
        ballPos[1] += ballVel[1]
        ballRect.centerx = ballPos[0]
        ballRect.centery = ballPos[1]
        
    
    # Blit Background
    
    screen.blit(background, (0, 0))
    
    # Screen Blit Objects
    
    screen.blit(ballSurf, ballRect)
    
    screen.blit(paddle1Surf, paddle1Rect)
    screen.blit(paddle2Surf, paddle2Rect)
    
    # Blit UI
    
    screen.blit(top, (0, 0))
    screen.blit(bottom, (0, 376))
    screen.blit(restartSurf, restartRect)
    
    screen.blit(paddle1ModeSurf, paddle1ModeRect)
    screen.blit(paddle2ModeSurf, paddle2ModeRect)
    
    if play:
        
        screen.blit(pauseSurf, (2, 2))
        
    else:
        
        screen.blit(playSurf, (2, 2))
        
    
    screen.blit(scoreDivide, (299, 2))
    
    screen.blit(numberImg[score[0] % 10], (278, 0))
    screen.blit(numberImg[math.floor(score[0] / 10) % 10], (266, 0))
    screen.blit(numberImg[math.floor(score[0] / 100) % 10], (254, 0))
    
    screen.blit(numberImg[math.floor(score[1] / 100) % 10], (310, 0))
    screen.blit(numberImg[math.floor(score[1] / 10) % 10], (322, 0))
    screen.blit(numberImg[score[1] % 10], (334, 0))
        
    # Update Display & FPS
    
    pygame.display.update()
    if not(turbo): clock.tick(FPS)
    time += 1
    

